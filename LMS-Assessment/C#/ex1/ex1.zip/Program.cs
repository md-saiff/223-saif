﻿using System;

namespace ex1
{
    class Program
    {

        static void Main(string[] args)

        {

            Employee d = new Employee();
            d.getDepartmentName();
            d.getNumberOfDepartment();
            d.getDepartmentDetail();
            d.getFirstName();
            d.getLastName();

        }




    }

}